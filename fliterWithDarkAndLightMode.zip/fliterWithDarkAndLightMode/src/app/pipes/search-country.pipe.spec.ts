import { SearchCountryPipe } from './search-country.pipe';

describe('SearchCountryPipe', () => {
  it('create an instance', () => {
    const pipe = new SearchCountryPipe();
    expect(pipe).toBeTruthy();
  });
});
