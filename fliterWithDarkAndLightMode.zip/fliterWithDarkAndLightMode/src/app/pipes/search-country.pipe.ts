import { Pipe, PipeTransform } from "@angular/core";

@Pipe({
  name: "searchCountry",
})
export class SearchCountryPipe implements PipeTransform {
  transform(value, input) {
    let filteredValue = [];
    if (!input || input === "") {
      return value;
    } else {
      value.forEach((element) => {
        if (element.name.toUpperCase().includes(input.toUpperCase())) {
          filteredValue.push(element);
        }
      });
      return filteredValue;
    }
  }
}
