import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ThemeService } from "../themes/theme.service";

@Component({
  selector: 'app-details',
  templateUrl: './details.component.html',
  styleUrls: ['./details.component.css']
})
export class DetailsComponent implements OnInit {

  constructor(public route:Router, private themeService: ThemeService) { }

  ngOnInit() {
  }
  backFunction(){
    this.route.navigate(['/home']);
  }

toggle() {
  console.log('toggle hua');
  
    const active = this.themeService.getActiveTheme();
    if (active.name === "light") {
      this.themeService.setTheme("dark");
    } else {
      this.themeService.setTheme("light");
    }
  }

}
