import { BrowserModule } from "@angular/platform-browser";
import { NgModule } from "@angular/core";
import { RouterModule } from "@angular/router";
import { AppRoutingModule } from "./app-routing.module";
import { AppComponent } from "./app.component";
import { HomeComponent } from "./home/home.component";
import { CountryDataService } from "./services/country-data.service";
import { HttpClientModule } from "@angular/common/http";
import { DetailsComponent } from "./details/details.component";
import { FormsModule } from "@angular/forms";
import { Ng2SearchPipeModule } from "ng2-search-filter";
import { SearchCountryPipe } from "./pipes/search-country.pipe";
import { ThemeModule } from "../app/themes/theme.module";
import { lightTheme } from "../app/themes/light-theme";
import { darkTheme } from "../app/themes/dark-theme";

@NgModule({
  declarations: [
    AppComponent,
    HomeComponent,
    DetailsComponent,
    SearchCountryPipe,
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    RouterModule,
    FormsModule,
    Ng2SearchPipeModule,
    ThemeModule.forRoot({
      themes: [lightTheme, darkTheme],
      active: "light",
    }),
  ],
  providers: [CountryDataService],
  bootstrap: [AppComponent],
})
export class AppModule {}
