import { Theme } from "./symbol";

export const darkTheme: Theme = {
  name: "dark",
  properties: {
    "--background": "#1F2125",
    "--background-gray": "#6b5050",
    "--on-background": "#fff",
    "--primary": "darkorange",
    "--on-primary": "#fff",
  },
};
