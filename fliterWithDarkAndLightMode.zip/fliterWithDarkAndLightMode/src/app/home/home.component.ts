import { Component, OnInit } from "@angular/core";
import { HttpClient, HttpErrorResponse } from "@angular/common/http";
import { CountryDataService } from "../services/country-data.service";
import { ThemeService } from "../themes/theme.service";

@Component({
  selector: "app-home",
  templateUrl: "./home.component.html",
  styleUrls: ["./home.component.css"],
})
export class HomeComponent implements OnInit {
  Data: any;
  initialCountry: any;
  countryName;
  continent;
  filter = [
    { label: "All", value: "All" },
    { label: "Africa", value: "Africa" },
    { label: "Americas", value: "Americas" },
    { label: "Asia", value: "Asia" },
    { label: "Europe", value: "Europe" },
    { label: "Oceania", value: "Oceania" },
  ];

  constructor(
    public countryDataService: CountryDataService,
    private themeService: ThemeService
  ) {}

  ngOnInit() {
    this, this.getCountryData();
  }

  getCountryData() {
    this.countryDataService.getCountryData().subscribe(
      (res: any) => {
        this.Data = res;
        this.initialCountry = res;
        console.log(this.Data);
      },
      (err: HttpErrorResponse) => {
        console.log("error", err);
      }
    );
  }

  onRegionSelect(event) {
    console.log(event.target.value);
    this.Data = this.initialCountry;
    let filteredCountry: any = [];
    if (event.target.value === "All") {
      this.Data = this.initialCountry;
    } else {
      this.Data.filter((country) => {
        if (country.region === event.target.value) {
          filteredCountry.push(country);
        }
      });
      this.Data = filteredCountry;
    }
  }

  toggle() {
    const active = this.themeService.getActiveTheme();
    if (active.name === "light") {
      this.themeService.setTheme("dark");
    } else {
      this.themeService.setTheme("light");
    }
  }
}
